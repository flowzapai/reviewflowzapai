var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/review-requests/send.js")
R.c("server/chunks/[root-of-the-server]__0bddvwh._.js")
R.c("server/chunks/[root-of-the-server]__00qqec5._.js")
R.m(8945)
module.exports=R.m(8945).exports
