__turbopack_load_page_chunks__("/dashboard/clients", [
  "static/chunks/0cb97ybhbta5_.js",
  "static/chunks/0k5_.~mcfd6h-.js",
  "static/chunks/1445m69s7l345.js",
  "static/chunks/0v_ah0suzg~w_.js",
  "static/chunks/05d5~r9e26itm.css",
  "static/chunks/turbopack-0y8yc303zepn..js"
])
