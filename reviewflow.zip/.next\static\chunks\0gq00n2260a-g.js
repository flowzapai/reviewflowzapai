__turbopack_load_page_chunks__("/dashboard", [
  "static/chunks/0u.yspn8w4ll..js",
  "static/chunks/0k5_.~mcfd6h-.js",
  "static/chunks/1445m69s7l345.js",
  "static/chunks/0v_ah0suzg~w_.js",
  "static/chunks/0l7l8oatk22vd.css",
  "static/chunks/turbopack-05h2t34doux-8.js"
])
