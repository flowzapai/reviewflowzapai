__turbopack_load_page_chunks__("/_app", [
  "static/chunks/0apwjhri2cfrj.js",
  "static/chunks/0k5_.~mcfd6h-.js",
  "static/chunks/0v_ah0suzg~w_.js",
  "static/chunks/1445m69s7l345.js",
  "static/chunks/0qy8omb05nqhr.css",
  "static/chunks/turbopack-09xnkyw4l.y1j.js"
])
