var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/settings.js")
R.c("server/chunks/[root-of-the-server]__0gyy_sr._.js")
R.c("server/chunks/[root-of-the-server]__00qqec5._.js")
R.m(2991)
module.exports=R.m(2991).exports
