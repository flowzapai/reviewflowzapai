self.__BUILD_MANIFEST = {
  "/_error": [
    "static/chunks/02bktk.a7.jzk.js"
  ],
  "/dashboard": [
    "static/chunks/0gq00n2260a-g.js"
  ],
  "/dashboard/clients": [
    "static/chunks/0v1tbpuy-p9h1.js"
  ],
  "/dashboard/settings": [
    "static/chunks/04ojfkcly854l.js"
  ],
  "/login": [
    "static/chunks/17h6ls114jsz..js"
  ],
  "/register": [
    "static/chunks/06gh6sp110vi..js"
  ],
  "__rewrites": {
    "afterFiles": [],
    "beforeFiles": [],
    "fallback": []
  },
  "sortedPages": [
    "/_app",
    "/_error",
    "/api/auth/register",
    "/api/avaliacao/submit",
    "/api/clients",
    "/api/review-requests/send",
    "/api/settings",
    "/api/stats",
    "/dashboard",
    "/dashboard/clients",
    "/dashboard/settings",
    "/login",
    "/register"
  ]
};self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB()