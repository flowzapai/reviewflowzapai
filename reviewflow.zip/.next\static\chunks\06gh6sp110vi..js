__turbopack_load_page_chunks__("/register", [
  "static/chunks/06fgnlltq293v.js",
  "static/chunks/0k5_.~mcfd6h-.js",
  "static/chunks/1445m69s7l345.js",
  "static/chunks/0v_ah0suzg~w_.js",
  "static/chunks/0ixk~e2624ck8.css",
  "static/chunks/turbopack-02df17n_61y.z.js"
])
