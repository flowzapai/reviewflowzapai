var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/auth/register.js")
R.c("server/chunks/[root-of-the-server]__0wj9.ax._.js")
R.c("server/chunks/[root-of-the-server]__00qqec5._.js")
R.m(34)
module.exports=R.m(34).exports
