globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/0apwjhri2cfrj.js",
      "static/chunks/0k5_.~mcfd6h-.js",
      "static/chunks/0v_ah0suzg~w_.js",
      "static/chunks/1445m69s7l345.js",
      "static/chunks/0qy8omb05nqhr.css",
      "static/chunks/turbopack-09xnkyw4l.y1j.js"
    ],
    "/_error": [
      "static/chunks/07-052ms10wq6.js",
      "static/chunks/0k5_.~mcfd6h-.js",
      "static/chunks/1445m69s7l345.js",
      "static/chunks/0v_ah0suzg~w_.js",
      "static/chunks/turbopack-0fjhcz0j-vds..js"
    ],
    "/dashboard": [
      "static/chunks/0u.yspn8w4ll..js",
      "static/chunks/0k5_.~mcfd6h-.js",
      "static/chunks/1445m69s7l345.js",
      "static/chunks/0v_ah0suzg~w_.js",
      "static/chunks/0l7l8oatk22vd.css",
      "static/chunks/turbopack-05h2t34doux-8.js"
    ],
    "/dashboard/clients": [
      "static/chunks/0cb97ybhbta5_.js",
      "static/chunks/0k5_.~mcfd6h-.js",
      "static/chunks/1445m69s7l345.js",
      "static/chunks/0v_ah0suzg~w_.js",
      "static/chunks/05d5~r9e26itm.css",
      "static/chunks/turbopack-0y8yc303zepn..js"
    ],
    "/dashboard/settings": [
      "static/chunks/0fdq~qihgzjgu.js",
      "static/chunks/0k5_.~mcfd6h-.js",
      "static/chunks/1445m69s7l345.js",
      "static/chunks/0v_ah0suzg~w_.js",
      "static/chunks/03lodz2~leeeq.css",
      "static/chunks/turbopack-13i5jkyq~ls0g.js"
    ],
    "/login": [
      "static/chunks/16o32uaweef8p.js",
      "static/chunks/0k5_.~mcfd6h-.js",
      "static/chunks/0v_ah0suzg~w_.js",
      "static/chunks/1445m69s7l345.js",
      "static/chunks/05t0e0kdueedb.css",
      "static/chunks/turbopack-08dmowlc5-e2d.js"
    ],
    "/register": [
      "static/chunks/06fgnlltq293v.js",
      "static/chunks/0k5_.~mcfd6h-.js",
      "static/chunks/1445m69s7l345.js",
      "static/chunks/0v_ah0suzg~w_.js",
      "static/chunks/0ixk~e2624ck8.css",
      "static/chunks/turbopack-02df17n_61y.z.js"
    ]
  },
  "devFiles": [],
  "polyfillFiles": [],
  "lowPriorityFiles": [
    "static/iHYaiae8qLgvDQEEv0b33/_buildManifest.js",
    "static/iHYaiae8qLgvDQEEv0b33/_ssgManifest.js",
    "static/iHYaiae8qLgvDQEEv0b33/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": []
};
