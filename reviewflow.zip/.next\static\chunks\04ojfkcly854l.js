__turbopack_load_page_chunks__("/dashboard/settings", [
  "static/chunks/0fdq~qihgzjgu.js",
  "static/chunks/0k5_.~mcfd6h-.js",
  "static/chunks/1445m69s7l345.js",
  "static/chunks/0v_ah0suzg~w_.js",
  "static/chunks/03lodz2~leeeq.css",
  "static/chunks/turbopack-13i5jkyq~ls0g.js"
])
