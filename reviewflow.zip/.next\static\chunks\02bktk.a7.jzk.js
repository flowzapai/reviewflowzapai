__turbopack_load_page_chunks__("/_error", [
  "static/chunks/07-052ms10wq6.js",
  "static/chunks/0k5_.~mcfd6h-.js",
  "static/chunks/1445m69s7l345.js",
  "static/chunks/0v_ah0suzg~w_.js",
  "static/chunks/turbopack-0fjhcz0j-vds..js"
])
