var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/clients.js")
R.c("server/chunks/[root-of-the-server]__01hnznb._.js")
R.c("server/chunks/[root-of-the-server]__00qqec5._.js")
R.m(5862)
module.exports=R.m(5862).exports
