var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/stats.js")
R.c("server/chunks/[root-of-the-server]__10~iq3k._.js")
R.c("server/chunks/[root-of-the-server]__00qqec5._.js")
R.m(1887)
module.exports=R.m(1887).exports
