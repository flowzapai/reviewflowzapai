__turbopack_load_page_chunks__("/login", [
  "static/chunks/16o32uaweef8p.js",
  "static/chunks/0k5_.~mcfd6h-.js",
  "static/chunks/0v_ah0suzg~w_.js",
  "static/chunks/1445m69s7l345.js",
  "static/chunks/05t0e0kdueedb.css",
  "static/chunks/turbopack-08dmowlc5-e2d.js"
])
