self.__BUILD_MANIFEST = {
  "__rewrites": {
    "afterFiles": [],
    "beforeFiles": [],
    "fallback": []
  },
  "sortedPages": [
    "/_app",
    "/_error",
    "/api/auth/register",
    "/api/auth/[login]",
    "/api/avaliacao/submit",
    "/api/clients",
    "/api/review-requests/send",
    "/api/settings",
    "/api/stats",
    "/avaliacao/[companyId]/[clientId]",
    "/dashboard",
    "/dashboard/clients",
    "/dashboard/settings",
    "/login",
    "/register"
  ]
};self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB()