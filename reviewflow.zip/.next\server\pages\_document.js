var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_document.js")
R.c("server/chunks/ssr/[externals]__0wesech._.js")
R.c("server/chunks/ssr/[root-of-the-server]__0uul4yb._.js")
R.m(3590)
module.exports=R.m(3590).exports
