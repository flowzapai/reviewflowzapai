var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/avaliacao/submit.js")
R.c("server/chunks/[root-of-the-server]__03kl2no._.js")
R.c("server/chunks/[root-of-the-server]__00qqec5._.js")
R.m(4647)
module.exports=R.m(4647).exports
